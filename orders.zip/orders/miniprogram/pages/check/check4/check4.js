Page({

  /**
   * 页面的初始数据
   */
  data: {
    datalist:[],
    hiddenName:true,
    showId:null
  },

  getData(num=5,page=0){
    wx.cloud.callFunction({
      name:"demolist",
      data:{
        num:num,
        page:page
      }
    }).then(res=>{
      var oldData=this.data.datalist
      var newData=oldData.concat(res.result.data)
      this.setData({
        datalist:newData
      })
    })
  },
// 点击将阅读量增加
click(res){
  wx.showLoading({
    title: '数据加载中...',
    mask:true
  })

  var {id,idx}=res.currentTarget.dataset;
  
  wx.cloud.callFunction({
    name:"demoUplist",
    data:{
      id:id
    }
  }).then(res=>{
    var newData=this.data.datalist
    newData[idx].hits+=1;
    this.setData({
      datalist:newData
    })
    wx.hideLoading()
  })
},

// clickMe:function(e){
//   this.setData({
//       hiddenName:!this.data.hiddenName
//   })
// },

setItem(e) {
  this.setData({
    pageIndex: 1,
    list: [],
  })
  this.setData({
    showId: e.currentTarget.dataset.id
  });
},


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData()
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var page=this.data.datalist.length
    this.getData(5,page)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})