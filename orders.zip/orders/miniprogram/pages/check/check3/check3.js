Page({

  /**
   * 页面的初始数据
   */
  data: {
    container:"在电子阅览室，光盘检索以其信息量大、检索方便快捷而赢得广大读者的青睐，是电子阅览室服务的最主要功能。利用光盘，可以对题名、关键词、作者、机构等各种字段进行检索。文）数据库》、万方学位论文数据库（网络版）和中文期刊数据库等。总之，CD－ROM数据库几乎成为各国图书馆信息数据库的支柱，是高校师生获取最新学术信息的重要来源。",
    imgUrls: [
      {
        goodsid: 1, img_path: '../check/img/c1.jpg'
      },
      {
        goodsid: 1, img_path: '../check/img/c2.jpg'
      }
    ]
  },

  select:function(e){
    wx.navigateTo({
      url: '/pages/select/select',
    })
   },
//转发
onShareAppMessage: function(res) {
  if (res.from === 'button') {
    console.log(res.target)
  }
  return {
    title: '转发',
    path: '/pages/check3/check3'
  }
},
//分享到朋友圈
onShareTimeline: function () {
  return {
      title: ''
  }
},
onShareAppMessage: function () {
return {
  title: ''
}
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})