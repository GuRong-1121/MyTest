Page({
  data:{
    info:[
      {
        label:'姓名',
        value:'顾荣'
      },
      {
        label: '职业',
        value: '学生'
      },
      {
        label: 'QQ',
        value: '137596665'
      },
      {
        label: '微信',
        value: '189****7559'
      }
    ]
  },
    //转发
    onShareAppMessage: function(res) {
      if (res.from === 'button') {
        console.log(res.target)
      }
      return {
        title: '转发',
        path: '/pages/about/about'
      }
    },
    //分享到朋友圈
    onShareTimeline: function () {
      return {
          title: ''
      }
  },
  onShareAppMessage: function () {
    return {
      title: ''
    }
  },
})