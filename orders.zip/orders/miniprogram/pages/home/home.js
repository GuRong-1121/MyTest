//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    indicatorDots: true,//是否显示面板指示点
    autoplay: true,
    interval: 2000,//自动切换时间间隔
    duration: 1000,//滑动动画时长
    indicatorColor: "#eee",//普通轮播点背景色
    indicatorActiveColor: "#f10215",//选中轮播点背景色
    imgUrls: [
      {
        goodsid: 1, img_path: 'cloud://gr-f01c4a.6772-gr-f01c4a-1258393931/imgimg/1.jpg'
      },
      {
        goodsid: 2, img_path: 'cloud://gr-f01c4a.6772-gr-f01c4a-1258393931/imgimg/2.jpg'
      },
      {
        goodsid: 3, img_path: 'cloud://gr-f01c4a.6772-gr-f01c4a-1258393931/imgimg/3.jpg'
      },
      {
        goodsid: 3, img_path: 'cloud://gr-f01c4a.6772-gr-f01c4a-1258393931/imgimg/4.jpg'
      }
    ],
  },

  checkItem1:function(e){
    wx.navigateTo({
      url: '../../pages/check/check1/check1'
    })
  },
  checkItem2:function(e){
    wx.navigateTo({
      url: '../../pages/check/check2/check2'
    })
  },
  checkItem3:function(e){
    wx.navigateTo({
      url: '../../pages/check/check3/check3'
    })
  },
  checkItem4:function(e){
    wx.navigateTo({
      url: '../../pages/check/check4/check4'
    })
  },
  //转发
onShareAppMessage: function(res) {
  if (res.from === 'button') {
    console.log(res.target)
  }
  return {
    title: '转发',
    path: '/pages/home/home'
  }
},
//分享到朋友圈
onShareTimeline: function () {
  return {
      title: ''
  }
},
onShareAppMessage: function () {
return {
  title: ''
}
},
});