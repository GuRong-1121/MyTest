//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    logs: []
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  },
  //转发
  onShareAppMessage: function(res) {
    if (res.from === 'button') {
      console.log(res.target)
    }
    return {
      title: '转发',
      path: '/pages/logs/logs'
    }
  },
  //分享到朋友圈
  onShareTimeline: function () {
    return {
        title: ''
    }
},
onShareAppMessage: function () {
  return {
    title: ''
  }
},
})
